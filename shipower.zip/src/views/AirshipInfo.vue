<template>
  <div class="airship">
    <div class="title">空船信息</div>
    <div class="searchBox">
      <el-input placeholder="请输入船舶名称" prefix-icon="el-icon-search" v-model="inputAirship"></el-input>
      <el-button type="primary" @click="searchAirshipInfo">搜索</el-button>
    </div>
    <el-table
      :data="airshipInfo"
      border
      style="width:98%;max-height:69vh">
      <el-table-column label="序号" type="index" width="60"> </el-table-column>
      <el-table-column label="船舶名称" prop="shipName"></el-table-column>
      <el-table-column label="船东姓名" prop="name"></el-table-column>
      <el-table-column label="联系电话" prop="phone"></el-table-column>
      <el-table-column label="空船日期" prop="emptyShipDate">
        <template slot-scope="scope"><span v-if="scope.row.emptyShipDate != null">{{formateDate(scope.row.emptyShipDate,1)}}</span></template>
      </el-table-column>
      <el-table-column label="船舶类型" prop="shipType">
        <template slot-scope="scope">
          <span v-if="scope.row.shipType == 1">散货船</span>
          <span v-else-if="scope.row.shipType == 2">平板船</span>
          <span v-else-if="scope.row.shipType == 3">拖船</span>
          <span v-else-if="scope.row.shipType == 4">罐装船</span>
          <span v-else-if="scope.row.shipType == 5">集装箱船</span>
          <span v-else>其他</span>
        </template>
      </el-table-column>
      <el-table-column label="船舶吨位" prop="tunnage"></el-table-column>
      <el-table-column label="空船港" prop="emptyPort"></el-table-column>
      <el-table-column label="目的港" prop="destiPort1"></el-table-column>
      <el-table-column label="提交时间" prop="createTime">
        <template slot-scope="scope"><span v-if="scope.row.createTime != null">{{formateDate(scope.row.createTime,2)}}</span></template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="danger" 
            icon="el-icon-delete" 
            size="mini" 
            circle
            :disabled="!scope.row.status"
            @click="DeleteAirshipInfo(scope.row.ssid)"></el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      layout="prev, pager, next"
      :page-size="12"
      :current-page.sync='currPageNum'
      :total="airshipTotal"
      @current-change="handleCurrentChange">
    </el-pagination>
  </div>
</template>
<script>
import $ from 'jquery';
export default {
  name: 'AirshipInfo',
  data () {
    return {
      inputAirship:'',
      airshipInfo:[],
      airshipTotal:0,
      currPageNum:1
    }
  },
  mounted(){
    this.getAirshipData(1,"");
  },
  methods: {
    formateDate(timestamp,_type){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? ('0' + minute) : minute;
      if(_type == 1){
        return y + '-' + m + '-' + d;
      }else{
        return y + '-' + m + '-' + d+' '+h+':'+minute;
      }
    },
    getAirshipData(_pageNo,_seacraft){
      $.ajax({
        type: "post",
        url: "/supply-ship/page?pageNo="+_pageNo+"&shipName="+_seacraft,
        dataType: "json",
        success: (data) => {
          if(data.ret !=0){
            console.log(data.msg);
            return;
          }
          this.airshipInfo = data.data.list;
          this.airshipTotal = data.data.totalCount;
        },
        error: (data)=>{console.log(data)}
      }); 
    },
    searchAirshipInfo(){
      this.currPageNum = 1;
      this.getAirshipData(this.currPageNum,this.inputAirship);
    },
    DeleteAirshipInfo(_ssid){
      this.$alert('是否删除此条空船数据？', {
        confirmButtonText: '确定',
        callback: action => {
          $.ajax({
            type: "post",
            url: "/supply-ship/del?ssid="+_ssid,
            dataType: "json",
            success: (data) => {
              if(data.ret !=0){
                console.log(data.msg);
                return;
              }
              this.$message({type: 'info',message: `删除成功！`});
              this.currPageNum = 1;
              this.getAirshipData(this.currPageNum,this.inputAirship);
            },
            error: (data) => {console.log(data)}
          });          
        }
      }); 
    },
    handleCurrentChange(val){
      this.currPageNum = val;
      this.getAirshipData(val,this.inputAirship);
    }
  }
}
</script>
<style scoped>
.airship{height: 100%; background: #fff;}
</style>