<template>
  <div class="home">
    <div class="header">
      <div class="logo">好运船东版后台管理系统</div>
      <div class="user">
        <el-tooltip content="退出" placement="bottom" effect="light">
          <a class="quit" @click="LogOut"><i class="el-icon-switch-button"></i></a>
        </el-tooltip>
        <el-tooltip content="修改密码" placement="bottom" effect="light">
          <span class="changepwdBtn" @click="dialogChangePwd=true"><i class="el-icon-unlock"></i></span> 
        </el-tooltip>        
        <span>{{userName}}</span>
      </div>
    </div>
    <div class="main">
      <div class="aside">
        <ul class="menu">
          <li><router-link :to="{name: 'sourceInfo'}"><i class="el-icon-box"></i> 货源信息</router-link></li>
          <li><router-link :to="{name: 'shipInfo'}"><i class="el-icon-ship"></i> 船舶信息</router-link></li>
          <li><router-link :to="{name: 'airshipInfo'}"><i class="el-icon-postcard"></i> 空船信息</router-link></li>
          <li><router-link :to="{name: 'memberInfo'}"><i class="el-icon-star-off"></i> 会员信息</router-link></li>
          <li><router-link :to="{name: 'deviceManage'}"><i class="el-icon-video-camera"></i> 设备管理</router-link></li>
          <li><router-link :to="{name: 'userManage'}"><i class="el-icon-user"></i> 用户管理</router-link></li>
          <li><router-link :to="{name: 'dataMaintain'}"><i class="el-icon-monitor"></i> 数据维护</router-link></li>
          <li><router-link :to="{name: 'CBFI'}"><i class="el-icon-s-data"></i> 运价指数</router-link></li>
        </ul>
      </div>
      <div class="content"><router-view /></div>
    </div>
    <el-dialog
      title="修改密码"
      :visible.sync="dialogChangePwd"
      width="20%">
      <el-form>
        <el-form-item label="旧密码">
          <el-input v-model="oldPassword" placeholder="请输入旧密码"></el-input>
        </el-form-item>
        <el-form-item label="新密码">
          <el-input v-model="newPassword" placeholder="请输入新密码"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogChangePwd = false">取 消</el-button>
        <el-button type="primary" @click="handleClickChangePwd">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'Home',
  data () {
    return {
      dialogChangePwd:false,
      oldPassword:'',
      newPassword:'',
      userName:''
    }
  },
  mounted() {
    this.userName = sessionStorage.getItem("loginName");
  },
  methods: {
    handleClickChangePwd(){
      $.ajax({
        type: "post",
        url: "/user/change-pwd?oldPwd="+this.oldPassword+"&newPwd="+this.newPassword,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.$message({type: 'success', message: '密码修改成功!'});
          this.dialogChangePwd = false;
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    LogOut() {
      $.ajax({
        type: "post",
        url: "/logout",
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.$router.push('/');
        },
        error: (data)=>{console.log(data);}
      }); 
    }
  }
}
</script>
<style scoped>
.home{width:100vw;height:100vh;}
.header{ height:65px; padding:0 20px; line-height:65px; color:#fff; background:#5B8DFF;}
.logo{float:left; padding-left:2vw; font-size:30px; background:url("../assets/logo.png") no-repeat 0 center; background-size:auto 75%;}
.user{float:right; font-size:20px;}
.user>.changepwdBtn{margin:0 10px; cursor:pointer;}
.user>.quit{color:#fff; cursor:pointer;}
.main{width:100%; height:calc(100% - 85px); background:#f0f3fa; padding-top: 20px; display:flex; justify-content:space-between;}
.aside{width:8%; background:#ffffff;}
.menu>li{height:50px; text-align:center; line-height:50px;}
.menu>li>a{display:block; width:100%; height:100%;color:#41547b; font-size:1.85vh;}
.content{width:91%;}
.menu>li>a.active{color:#fff; background:#5A8CFF}
</style>