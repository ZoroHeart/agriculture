<template>
  <div class="shipInfo">
    <div class="title">船舶信息</div>
    <div class="searchBox">
      <el-input
        placeholder="请输入船舶名称"
        prefix-icon="el-icon-search"
        v-model="inputShipName">
      </el-input>
      <el-button type="primary" @click="searchShipsInfo">搜索</el-button>
    </div>
    <el-table :data="shipDatas" border style="width:98%;max-height:68vh">
      <el-table-column type="index" label="序号" width="50"></el-table-column>
      <el-table-column prop="shipName" label="船舶名称"></el-table-column>
      <el-table-column prop="name" label="船东姓名"></el-table-column>
      <el-table-column prop="phone" label="联系电话"></el-table-column>
      <el-table-column prop="isBind" label="是否安装摄像头">
        <template slot-scope="scope">
          <span v-if="scope.row.isBind == 1">是</span>
          <span v-else>否</span>
        </template>
      </el-table-column>
      <el-table-column prop="shipType" label="船舶类型">
        <template slot-scope="scope">
          <span v-if="scope.row.shipType == 1">散货船</span>
          <span v-else-if="scope.row.shipType == 2">平板船</span>
          <span v-else-if="scope.row.shipType == 3">拖船</span>
          <span v-else-if="scope.row.shipType == 4">罐装船</span>
          <span v-else-if="scope.row.shipType == 5">集装箱船</span>
          <span v-else>其他</span>
        </template>
      </el-table-column>
      <el-table-column prop="tunnage" label="船舶吨位"></el-table-column>
      <el-table-column prop="staffGauge" label="水尺" width="310">
        <template slot-scope="scope"><span>{{makeupStaffGauge(scope.row.staffGauge)}}</span></template>
      </el-table-column>
      <el-table-column prop="cabinType" label="封舱类型" width="80">
        <template slot-scope="scope">
          <span v-if="scope.row.cabinType == 1">无封仓</span>
          <span v-else-if="scope.row.cabinType == 2">棚架</span>
          <span v-else-if="scope.row.cabinType == 3">雨布</span>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="提交时间">
        <template slot-scope="scope"><span v-if="scope.row.createTime != null">{{formateDate(scope.row.createTime)}}</span></template>
      </el-table-column>
      <el-table-column label="操作" width="60">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" content="删除" placement="right">
            <el-button 
              type="danger" 
              icon="el-icon-delete" 
              size="mini" 
              circle
              :disabled="!scope.row.status"
              @click="DeleteShipInfo(scope.row.sid)"></el-button>
          </el-tooltip>
        </template>        
      </el-table-column>
    </el-table>
    <el-pagination
      background
      layout="prev, pager, next"
      :page-size="12"
      :current-page.sync='currPageNum'
      :total="shipsTotal"
      @current-change="handleCurrPageChange">
    </el-pagination>
  </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'ShipInfo',
  data () {
    return {
      shipDatas: [],
      shipsTotal: 0,
      inputShipName: "",
      currPageNum:1
    }
  },
  beforeMount() {
    this.getShipInfoDatas(1,"");
  },
  methods: {
    formateDate(timestamp){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? ('0' + minute) : minute;
      return y + '-' + m + '-' + d+' '+h+':'+minute;
    },
    makeupStaffGauge(_staffGauge){
      var m = _staffGauge.split(",");
      var staffGauge = '';
      for(var i=0; i<m.length; i++){
        var _str = '';
        if(m[i] == '1'){
          _str = '马刚水尺';
        }else if(m[i] == '2'){
          _str = '武钢水尺';
        }else if(m[i] == '3'){
          _str = '重刚水尺';
        }else if(m[i] == '4'){
          _str = '船检所水尺';
        }
        staffGauge=staffGauge+_str+'，';
      }
      staffGauge=staffGauge.substring(0,staffGauge.length-1);
      return staffGauge;
    },
    getShipInfoDatas(_pageNo,_shipName) {
      $.ajax({
          type: "post",
          url: "/ship/page?pageNo="+_pageNo+"&shipName="+_shipName,
          dataType: "json",
          success: (data) => {
            if(data.ret !=0){
              this.$message({type: 'warning', message: data.msg});
              return;
            }
            this.shipDatas = data.data.list;
            this.shipsTotal = data.data.totalCount;
          },
          error: (data) => {console.log(data)}
      });
    },
    searchShipsInfo() {
      this.currPageNum = 1;
      this.getShipInfoDatas(1,this.inputShipName);
    },
    DeleteShipInfo(_sid) {
      this.$alert('是否删除此条数据？', {
        confirmButtonText: '确定',
        callback: action => {
          $.ajax({
            type: "post",
            url: "/ship/del?sid="+_sid,
            dataType: "json",
            success: (data) => {
              if(data.ret !=0){
                this.$message({type: 'warning', message: data.msg});
                return;
              }
              this.$message({type: 'info', message: `删除成功！`});
              this.getShipInfoDatas(this.currPageNum,this.inputShipName);
            },
            error: (data) => {console.log(data)}
          });          
        }
      });     
    },
    handleCurrPageChange(val) {
      this.currPageNum = val;
      this.getShipInfoDatas(val,this.inputShipName);
    }
  }
}
</script>
<style scoped>
.shipInfo{height:100%;background:#fff;}
</style>