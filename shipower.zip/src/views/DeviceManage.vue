<template>
  <div class="deviceManage">
    <div class="title">监控设备信息</div>
    <div class="searchBox">
      <el-form :inline="true" :model="inputData" style="padding-left:20px;">
        <div>
          <el-form-item label="设备ID">
            <el-input v-model="inputData.inputDevicesID" placeholder="请输入设备ID"></el-input>
          </el-form-item>
          <el-form-item label="安装人员">
            <el-select v-model="inputData.inputDevicesPerson" placeholder="安装人员">
              <el-option value="" label="全部">全部</el-option>
              <el-option 
                v-for="item in installList"
                :key="item.mid"
                :value="item.mid" 
                :label="item.name">{{item.name}}</el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="安装时间">
            <el-date-picker
              v-model="inputData.inputBeginDate"
              type="date"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
              placeholder="选择日期">
            </el-date-picker>
            -
            <el-date-picker
              v-model="inputData.inputEndDate"
              type="date"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
              placeholder="选择日期">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="searchDevicesData">搜索</el-button>
          </el-form-item>
        </div>
      </el-form>
    </div>
    <el-table :data="devicesDatas" border style="width:98%">
      <el-table-column type="index" label="序号" width="50"></el-table-column>
      <el-table-column prop="vsn" label="录像机SN"></el-table-column>
      <el-table-column prop="vname" label="录像机名称"></el-table-column>
      <el-table-column prop="channels" label="频道数"></el-table-column>
      <el-table-column prop="csn" label="货舱摄像头SN"></el-table-column>
      <el-table-column prop="locations" label="摄像头安装对应位置"></el-table-column>
      <el-table-column prop="createTime" label="安装时间">
        <template slot-scope="scope"><span>{{formateDate(scope.row.createTime)}}</span></template>
      </el-table-column>
      <el-table-column prop="name" label="安装人员"></el-table-column>
      <el-table-column prop="phone" label="安装人员电话"></el-table-column>
    </el-table>
    <el-pagination
      background
      layout="prev, pager, next"
      :page-size="12"
      :current-page.sync='currPage'
      :total="devicesTotal"
      @current-change="handleCurrPageChange">
    </el-pagination>
  </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'DeviceManage',
  data () {
    return {
      inputData: {
        inputDevicesID: '',
        inputDevicesPerson: '',
        inputBeginDate:'',
        inputEndDate:''
      },
      devicesDatas: [],
      devicesTotal: 0,
      currPage:1,
      installList:[] // 安装人员
    }
  },
  beforeMount() {
    this.getInstallList();
  },
  mounted() {    
    this.getDeviceDatas(1,"","","","");
  },
  methods: {
    formateDate(timestamp){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? ('0' + minute) : minute;
      return y + '-' + m + '-' + d+' '+h+':'+minute;  
    },
    // 请求安装人员列表
    getInstallList(){
      $.ajax({
        type: "get",
        url: "/video/install",
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.installList = respMsg.data.list;
        },
        error: (data)=>{console.log(data);}
      });
    },
    getDeviceDatas(_pageNo, _vsn, _mid, _beginDate, _endDate) {
      if(_beginDate == null){
        _beginDate = ''
      }
      if(_endDate == null){
        _endDate = ''
      }
      $.ajax({
        type: "post",
        url: "/video/page?pageNo="+_pageNo+"&vsn="+_vsn+"&mid="+_mid+"&beginDate="+_beginDate+"&endDate="+_endDate,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.devicesDatas = respMsg.data.list;
          this.devicesTotal = respMsg.data.totalCount;
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    searchDevicesData() {
      this.currPage = 1;
      this.getDeviceDatas(1,this.inputData.inputDevicesID,this.inputData.inputDevicesPerson,this.inputData.inputBeginDate,this.inputData.inputEndDate);
    },
    handleCurrPageChange(val) {
      this.currPage = val;
      this.getDeviceDatas(val,"","","","");
    }
  }
}
</script>
<style scoped>
.deviceManage{height:100%;background:#fff;}
</style>