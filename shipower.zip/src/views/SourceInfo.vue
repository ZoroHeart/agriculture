<template>
  <div class="sourceInfo">
    <el-tabs v-model="activeName" @tab-click="handleTabClick">
      <el-tab-pane label="货源信息" name="first">
        <div>
          <div class="title">货源信息</div>
          <div class="searchBox">
            <el-input
              placeholder="请输入海轮名称"
              prefix-icon="el-icon-search"
              v-model="inputSeacraft">
            </el-input>
            <el-button type="primary" @click="searchGoodsInfo">搜索</el-button>
          </div>
          <el-table :data="goodsInfo" border style="width: 98%;height: 61vh;">
            <el-table-column label="序号" type="index" width="50"> </el-table-column>
            <el-table-column label="海轮名称" prop="seacraft"></el-table-column>
            <el-table-column label="始发港" prop="transPort"></el-table-column>
            <el-table-column label="目的港" prop="destiPort"></el-table-column>
            <el-table-column label="装货日期" prop="loadingDate" width="150">
              <template slot-scope="scope"><span v-if="scope.row.loadingDate != null">{{formateDate(scope.row.loadingDate,1)}}</span></template>
            </el-table-column>
            <el-table-column label="货物类型" prop="name"></el-table-column>
            <el-table-column label="吨位" prop="tunnage"></el-table-column>
            <el-table-column label="航运公司" prop="carrier" width="230"></el-table-column>
            <el-table-column label="联系电话" prop="carrierPhone"></el-table-column>
            <el-table-column label="船舶类型" prop="shipType">
              <template slot-scope="scope">
                <span v-if="scope.row.shipType == 1">散货船</span>
                <span v-else-if="scope.row.shipType == 2">平板船</span>
                <span v-else-if="scope.row.shipType == 3">拖船</span>
                <span v-else-if="scope.row.shipType == 4">罐装船</span>
                <span v-else-if="scope.row.shipType == 5">集装箱船</span>
                <span v-else>其他</span>
              </template>
            </el-table-column>
            <el-table-column label="发布时间" prop="createTime" width="150">
              <template slot-scope="scope"><span v-if="scope.row.createTime != null">{{formateDate(scope.row.createTime,2)}}</span></template>
            </el-table-column>
            <el-table-column label="业务节点" prop="steps">
              <template slot-scope="scope">
                <span v-if="scope.row.steps == 1">招标公示</span>
                <span v-else-if="scope.row.steps == 2">确认海轮</span>
                <span v-else-if="scope.row.steps == 3">海轮装货</span>
                <span v-else-if="scope.row.steps == 4">海轮到港</span>
              </template>
            </el-table-column>
            <el-table-column label="编辑" width="200">
              <template slot-scope="scope">
                <el-button
                  size="mini"
                  @click="changeGoodsInfo(scope.row)">货源信息
                </el-button>
                <el-popover
                  placement="right"
                  width="300"
                  trigger="click">
                  <div>
                    <div>
                      <el-form :inline="true" :model="inputBizNode">
                        <div>
                          <el-form-item label="流程节点">
                            <el-select v-model="inputBizNode.stepNum" placeholder="流程节点">
                              <el-option value="1" label="招标公示">招标公示</el-option>
                              <el-option value="2" label="确定海轮">确定海轮</el-option>
                              <el-option value="3" label="海轮装货">海轮装货</el-option>
                              <el-option value="4" label="海轮到港">海轮到港</el-option>
                            </el-select>
                          </el-form-item>
                          <el-form-item label="选择日期">
                              <el-date-picker type="date" v-model="inputBizNode.dateStep" value-format="yyyy-MM-dd" placeholder="选择日期"></el-date-picker>
                          </el-form-item>
                        </div>
                        <div>
                          <el-form-item>
                            <el-button type="primary" @click="PublishBizsNode(scope.row.sgid)">确定</el-button>
                          </el-form-item>
                        </div>        
                      </el-form>
                    </div>
                    <el-timeline>
                      <el-timeline-item
                        v-for="(activity, index) in activities"
                        :key="index"
                        :icon="activity.icon"
                        :type="activity.type"
                        :color="activity.color"
                        :timestamp="activity.timestamp">
                        {{activity.content}}
                      </el-timeline-item>
                    </el-timeline>
                  </div>
                  <el-button type="primary" plain slot="reference" size="mini" @click="EditBizsNode(scope.row.sgid)">业务节点</el-button>
                </el-popover>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            background
            layout="prev, pager, next"
            :page-size="12"
            :current-page.sync='currPage'
            :total="goodsTotal"
            @current-change="handleCurrPageChange">
          </el-pagination>
        </div>
      </el-tab-pane>
      <el-tab-pane label="发布货源" name="second">
        <div class="">
          <div class="title">基本信息</div>
          <el-form :inline="true" :model="baseInfo" :rules="baseInfoRules" ref="baseInfo" class="goods-form">
            <div>
              <el-form-item label="海轮名称" prop="seacraft">
                <el-input v-model="baseInfo.seacraft" maxlength="64" show-word-limit></el-input>
              </el-form-item>
              <el-form-item label="始发港口" prop="transPort">
                <el-select v-model="baseInfo.transPort" placeholder="始发港口">
                  <el-option value="张家港" label="张家港"></el-option>
                  <el-option value="扬子江" label="扬子江"></el-option>
                  <el-option value="太仓鑫海" label="太仓鑫海"></el-option>
                  <el-option value="太仓华能" label="太仓华能"></el-option>
                  <el-option value="江阴中信" label="江阴中信"></el-option>
                  <el-option value="南京西坝" label="南京西坝"></el-option>
                  <el-option value="扬州海昌" label="扬州海昌"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="目的港" prop="destiPort">
                <el-select v-model="baseInfo.destiPort" placeholder="目的港">
                  <el-option value="汉川电厂" label="汉川电厂"></el-option>
                  <el-option value="青山电厂" label="青山电厂"></el-option>
                  <el-option value="荆州电厂" label="荆州电厂"></el-option>
                  <el-option value="国电九江" label="国电九江"></el-option>
                  <el-option value="国华九江" label="国华九江"></el-option>
                  <el-option value="丰城电厂" label="丰城电厂"></el-option>
                  <el-option value="黄金埠电厂" label="黄金埠电厂"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="装货时间" prop="loadingDate">
                <el-date-picker type="date" v-model="baseInfo.loadingDate" placeholder="选择日期" value-format="yyyy-MM-dd"></el-date-picker>
              </el-form-item>
            </div>
            <div>
              <el-form-item label="货源名称" prop="name">
                <el-input v-model="baseInfo.name" maxlength="32" show-word-limit></el-input>
              </el-form-item>
              <el-form-item label="核载吨位" prop="tunnage">
                <el-input v-model="baseInfo.tunnage" type="number" min=0></el-input>
              </el-form-item>
              <el-form-item label="船舶类型">
                <el-select v-model="baseInfo.shipType" placeholder="船舶类型">
                  <el-option value="1" label="散货船"></el-option>
                  <el-option value="2" label="平板船"></el-option>
                  <el-option value="3" label="拖船"></el-option>
                  <el-option value="4" label="罐装船"></el-option>
                  <el-option value="5" label="集装箱船"></el-option>
                  <el-option value="-1" label="其他"></el-option>
                </el-select>
              </el-form-item>
            </div>
            <div>
              <el-form-item label="江轮吨位" prop="shipTunnage">                
                <el-radio-group v-model="baseInfo.shipTunnage">
                  <el-radio value="10000-15000吨" label="10000-15000吨"></el-radio>
                  <el-radio value="5000-10000吨" label="5000-10000吨"></el-radio>
                  <el-radio value="2000-5000吨" label="2000-5000吨"></el-radio>
                  <el-radio value="2000吨以下" label="2000吨以下"></el-radio>
                </el-radio-group>
              </el-form-item>
            </div>
            <div>
              <el-form-item label="航运公司" prop="carrier">
                <el-select v-model="baseInfo.carrier" placeholder="航运公司">
                  <el-option
                    v-for="item in carrierList"
                    :key="item.id"
                    :value="item.comp"
                    :label="item.comp">{{item.comp}}</el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="联系电话">
                <el-input v-model="baseInfo.carrierPhone" type="number" placeholder="联系电话"></el-input>
              </el-form-item> 
            </div>
            <div>
              <el-form-item label="备注信息">
                <el-input type="textarea" v-model="baseInfo.remark" maxlength="1000" show-word-limit rows="5" cols="100"></el-input>
              </el-form-item>
            </div>
            <div style="margin: 10px 0 0 10%;">
              <el-form-item>
                <el-button type="primary" @click="submitForm('baseInfo')">发布</el-button>
                <el-button @click="resetForm('baseInfo')">重置</el-button>
              </el-form-item>
            </div>        
          </el-form>
        </div>
      </el-tab-pane>      
    </el-tabs> 
    <!-- 修改货源信息弹窗 -->
    <el-dialog title="修改货源信息" :visible.sync="dialogGoodsInfo" width="70%">
      <el-form :inline="true" :model="editGoods">
      <div>
        <el-form-item label="海轮名称">
          <el-input v-model="editGoods.seacraft" maxlength="64" show-word-limit></el-input>
        </el-form-item>
        <el-form-item label="始发港口">
          <el-select v-model="editGoods.transPort" placeholder="始发港口">
            <el-option value="张家港" label="张家港"></el-option>
            <el-option value="扬子江" label="扬子江"></el-option>
            <el-option value="太仓鑫海" label="太仓鑫海"></el-option>
            <el-option value="太仓华能" label="太仓华能"></el-option>
            <el-option value="江阴中信" label="江阴中信"></el-option>
            <el-option value="南京西坝" label="南京西坝"></el-option>
            <el-option value="扬州海昌" label="扬州海昌"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="目的港">
          <el-select v-model="editGoods.destiPort" placeholder="目的港">
            <el-option value="汉川电厂" label="汉川电厂"></el-option>
            <el-option value="青山电厂" label="青山电厂"></el-option>
            <el-option value="荆州电厂" label="荆州电厂"></el-option>
            <el-option value="国电九江" label="国电九江"></el-option>
            <el-option value="国华九江" label="国华九江"></el-option>
            <el-option value="丰城电厂" label="丰城电厂"></el-option>
            <el-option value="黄金埠电厂" label="黄金埠电厂"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="装货时间">
            <el-date-picker 
              type="date" 
              v-model="editGoods.loadingDate" 
              placeholder="选择日期" 
              format="yyyy-MM-dd" 
              value-format="yyyy-MM-dd">
            </el-date-picker>
        </el-form-item>
      </div>
      <div>
        <el-form-item label="货源名称">
          <el-input v-model="editGoods.name" maxlength="32" show-word-limit></el-input>
        </el-form-item>
        <el-form-item label="核载吨位">
          <el-input v-model="editGoods.tunnage" maxlength="7" show-word-limit></el-input>
        </el-form-item>
        <el-form-item label="船舶类型">
          <el-select v-model="editGoods.shipType" placeholder="船舶类型">
            <el-option value="1" label="散货船"></el-option>
            <el-option value="2" label="平板船"></el-option>
            <el-option value="3" label="拖船"></el-option>
            <el-option value="4" label="罐装船"></el-option>
            <el-option value="5" label="集装箱船"></el-option>
            <el-option value="-1" label="其他"></el-option>
          </el-select>
        </el-form-item>
      </div>
      <div>
        <el-form-item label="江轮吨位">                
          <el-radio-group v-model="editGoods.shipTunnage">
            <el-radio value="10000-15000吨" label="10000-15000吨"></el-radio>
            <el-radio value="5000-10000吨" label="5000-10000吨"></el-radio>
            <el-radio value="2000-5000吨" label="2000-5000吨"></el-radio>
            <el-radio value="2000吨以下" label="2000吨以下"></el-radio>
          </el-radio-group>
        </el-form-item>
      </div>
      <div>
        <el-form-item label="航运公司">
          <el-select v-model="editGoods.carrier" placeholder="航运公司">
            <el-option
              v-for="item in carrierList"
              :key="item.id"
              :value="item.comp"
              :label="item.comp">{{item.comp}}</el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="联系电话">
          <el-input v-model="editGoods.carrierPhone" type="number" placeholder="联系电话"></el-input>
        </el-form-item> 
      </div>
      <div>
        <el-form-item label="备注信息">
          <el-input type="textarea" v-model="editGoods.remark" maxlength="1000" show-word-limit rows="5" cols="100"></el-input>
        </el-form-item>
      </div>       
    </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogGoodsInfo = false">取 消</el-button>
        <el-button type="primary" @click="EditGoodsInfo()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import $ from 'jquery';
export default {
  name: 'SourceInfo',
  data () {
    return {
      activeName: 'first', //tab切换显示第一个内容
      baseInfo: {
        seacraft: "", // 海轮名
        name: "", // 货源名
        tunnage: '',// 核载吨位
        shipType: '',
        shipTunnage:'', // 装船吨位
        transPort:'', // 始发港
        destiPort:'', // 目的港        
        loadingDate:'', // 装货时间
        carrier:'', // 航运公司
        carrierPhone:'', // 航运公司联系方式
        remark:'' // 备注
      },
      inputSeacraft:'', //搜索输入海轮名称
      goodsInfo:[], // 货源信息表格数据,
      goodsTotal:0, // 货源信息总数
      editGoods:  { // 编辑货源信息
        sgid:'',
        seacraft: '', // 海轮名
        name: '', // 货源名
        tunnage: '',// 核载吨位
        shipType: '',
        shipTunnage:'', // 装船吨位
        transPort:'', // 始发港
        destiPort:'', // 目的港        
        loadingDate:'', // 装货时间
        carrier:'', // 航运公司
        carrierPhone:'', // 航运公司联系方式
        remark:'' // 备注
      },
      shipTypeName: '',
      inputBizNode:{stepNum:'', dateStep:''},
      activities: [],
      currPage: 0,
      dialogGoodsInfo: false,
      carrierList:[], // 航运公示列表
      baseInfoRules: {
        seacraft: [
          {required: true, message: '请输入海轮名称', trigger: 'blur' },
        ],
        transPort: [
          { required: true, message: '请选择始发港', trigger: 'change' }
        ],
        destiPort: [
          { required: true, message: '请选择目的港', trigger: 'change' }
        ],
        loadingDate: [
          { required: true, message: '请选择日期', trigger: 'change' }
        ],
        name: [
          { required: true, message: '请输入货源名称', trigger: 'blur' },
        ],
        tunnage: [
          { required: true, message: '请输入核载吨位', trigger: 'blur' },
          { min: 1, max: 7, message: '长度在 1 到 7 个字符', trigger: 'blur' }
        ],
        shipTunnage: [
          { required: true, message: '请选择江轮吨位', trigger: 'change' }
        ],
        carrier: [
          { required: true, message: '请选择航运公司', trigger: 'change' }
        ]
      }
    }
  },
  beforeMount() {},
  mounted() {
    this.getGoodsData(1," ");
    this.getCarrierList();
  },
  watch:{
    'baseInfo.carrier': function (newval) {
      this.carrierList.forEach(element => {
        if(element.comp == newval){
          this.baseInfo.carrierPhone = element.carrierPhone;
        }
      });
    },
    'editGoods.carrier': function (newval) {
      this.carrierList.forEach(element => {
        if(element.comp == newval){
          this.editGoods.carrierPhone = element.carrierPhone;
        }
      });
    }
  },
  methods: {
    formateDate(timestamp,_type){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? ('0' + minute) : minute;
      if(_type == 1){
        return y + '-' + m + '-' + d;
      }else{
        return y + '-' + m + '-' + d+' '+h+':'+minute;
      }
      
    },
    // 货源信息头部tab切换
    handleTabClick(tab, event) {
      if(tab.label == '货源信息'){
        this.getGoodsData(1,"");
      }
    },
    // 输入验证
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.PublishInfo();
          this.$refs[formName].resetFields();
        }else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // 获取航运公司列表
    getCarrierList(){
      $.ajax({
          type: "post",
          url: "/carrier/list",
          dataType: "json",
          success: (respMsg) => {            
            if(respMsg.ret != 0){
              this.$message.error(respMsg.msg);
              return;
            }
            this.carrierList = respMsg.data.list;
          },
          error: (data)=>{console.log(data);}
      });  
    },
    // 发布货源信息
    PublishInfo() {
      $.ajax({
        type: "post",
        url: "/supply-goods/post?seacraft="+this.baseInfo.seacraft+"&transPort="+this.baseInfo.transPort+"&destiPort="+this.baseInfo.destiPort+"&loadingDate="+this.baseInfo.loadingDate+"&name="+this.baseInfo.name+"&tunnage="+this.baseInfo.tunnage+"&shipType="+this.baseInfo.shipType+"&shipTunnage="+this.baseInfo.shipTunnage+"&carrier="+this.baseInfo.carrier+"&carrierPhone="+this.baseInfo.carrierPhone+"&remark="+this.baseInfo.remark,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }               
          this.$message({type: 'success',message: '发布成功!'});
          this.baseInfo = {seacraft:'', name:'', tunnage:'', shipType:'', shipTunnage:'', transPort:'', destiPort:'', loadingDate:'', carrier:'', carrierPhone:'', remark:'-'}
        },
        error: (data)=>{console.log(data);}
      });     
    },   
    // 请求货源信息数据
    getGoodsData(_pageNo,_seacraft){
      $.ajax({
          type: "post",
          url: "/supply-goods/page?pageNo="+_pageNo+"&seacraft="+_seacraft,
          dataType: "json",
          success: (data) => {
            if(data.ret !=0){
              this.$message.error(data.msg);
              return;
            }
            this.goodsInfo = data.data.list;
            this.goodsTotal = data.data.totalCount;
          }
      }); 
    },
    // 搜索货源信息
    searchGoodsInfo(){
      this.currPage = 1;
      this.getGoodsData(1,this.inputSeacraft);
    },
    // 点击分页按钮
    handleCurrPageChange(val){
      this.currPage = val;
      this.getGoodsData(val,this.inputSeacraft);
    },
    // 编辑货源信息
    changeGoodsInfo(row){
      if(row.shipType == 1){
        this.editGoods.shipType = '散货船';
      }else if(row.shipType == 2){
        this.editGoods.shipType = '平板船';
      }else if(row.shipType == 3){
        this.editGoods.shipType = '拖船';
      }else if(row.shipType == 4){
        this.editGoods.shipType = '罐装船';
      }else if(row.shipType == 5){
        this.editGoods.shipType = '集装箱船';
      }else{
        this.editGoods.shipType = '其他';
      }
      this.shipTypeName = row.shipType;
      this.dialogGoodsInfo = true;
      this.editGoods.sgid = row.sgid;
      this.editGoods.seacraft = row.seacraft; // 海轮名
      this.editGoods.transPort = row.transPort; // 始发港
      this.editGoods.destiPort = row.destiPort; // 目的港
      this.editGoods.loadingDate = this.formateDate(row.loadingDate,2); // 装货时间--（时间戳转为标准时间）
      this.editGoods.name = row.name; // 货源名
      this.editGoods.tunnage = row.tunnage;// 核载吨位      
      this.editGoods.shipTunnage = row.shipTunnage; // 装船吨位--            
      this.editGoods.carrier = row.carrier; // 航运公司
      this.editGoods.carrierPhone = row.carrierPhone; // 航运公司联系方式
      this.editGoods.remark = row.remark; // 备注
    },
    // 修改货源信息
    EditGoodsInfo() {
      var a = /[0-9]/; 
      if(!a.test(this.editGoods.shipType)){
        this.editGoods.shipType = this.shipTypeName;
      }
      $.ajax({
        type: "post",
        url: "/supply-goods/update?seacraft="+this.editGoods.seacraft+"&transPort="+this.editGoods.transPort+"&destiPort="+this.editGoods.destiPort+"&loadingDate="+this.editGoods.loadingDate+"&name="+this.editGoods.name+"&tunnage="+this.editGoods.tunnage+"&shipType="+this.editGoods.shipType+"&shipTunnage="+this.editGoods.shipTunnage+"&carrier="+this.editGoods.carrier+"&carrierPhone="+this.editGoods.carrierPhone+"&remark="+this.editGoods.remark+"&sgid="+this.editGoods.sgid,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.dialogGoodsInfo = false;
          this.$message({type: 'success',message: '修改成功!'});
          this.currPage = 1;
          this.getGoodsData(1, this.inputSeacraft);
        },
        error: (data)=>{console.log(data);}
      });     
    },
    // 编辑业务节点
    EditBizsNode(_sgid) {
      this.inputBizNode.stepNum = '';
      this.inputBizNode.dateStep = '';
      $.ajax({
        type: "post",
        url: "/supply-goods/get?sgid="+_sgid,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          let _goodsFlow = respMsg.data.goodsFlow;
          let _activities = [
            { content: _goodsFlow.step1, timestamp: _goodsFlow.dateStep1, color: '#ff7c24', icon: 'el-icon-aim'}, 
            { content: _goodsFlow.step2, timestamp: _goodsFlow.dateStep2, color: '#ff7c24', icon: 'el-icon-aim'}, 
            { content: _goodsFlow.step3, timestamp: _goodsFlow.dateStep3, color: '#ff7c24', icon: 'el-icon-aim'}, 
            { content: _goodsFlow.step4, timestamp: _goodsFlow.dateStep4, color: '#ff7c24', icon: 'el-icon-aim'}
          ];
          _activities.forEach(element => {
            if(element.timestamp == null){
              element.timestamp = "待确定"
              element.color = ""
              element.icon = ""
            }else{
              element.timestamp = this.formateDate(element.timestamp,2);//.toString()
              element.color = "#ff7c24"
              element.icon = "el-icon-aim"
            }
          });
          this.activities = _activities;          
        },
        error: (data)=>{console.log(data);}
      });  
    },
    PublishBizsNode(_sgid) {
      let _stepNum = 1;
      $.ajax({
        type: "post",
        url: "/supply-goods/update-gf?sgid="+_sgid+"&steps="+this.inputBizNode.stepNum+"&stepDate="+this.inputBizNode.dateStep,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.EditBizsNode(_sgid);
          this.getGoodsData(this.currPage,this.inputSeacraft);
        },
        error: (data)=>{console.log(data);}
      });  
    }
  }
}
</script>
<style scoped>
.sourceInfo{height:100%;}
.goods-form{padding:0 20px; height:76vh;}
</style>