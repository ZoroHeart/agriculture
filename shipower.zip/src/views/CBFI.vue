<template>
  <div class="dataMaintain">
    <div class="inputInfo">
      <div class="title">录入数据</div>
      <el-form :inline="true" :model="inputCBFI" :rules="rules" ref="inputCBFI" style="padding-left:20px;">
        <el-form-item label="起点" prop="startPoint">
          <el-select v-model="inputCBFI.startPoint" placeholder="起点">
            <el-option value="张家港" label="张家港"></el-option>
            <el-option value="扬子江" label="扬子江"></el-option>
            <el-option value="太仓鑫海" label="太仓鑫海"></el-option>
            <el-option value="太仓华能" label="太仓华能"></el-option>
            <el-option value="江阴中信" label="江阴中信"></el-option>
            <el-option value="南京西坝" label="南京西坝"></el-option>
            <el-option value="扬州海昌" label="扬州海昌"></el-option>
          </el-select>
        </el-form-item>        
        <el-form-item label="终点" prop="endPoint">
          <el-select v-model="inputCBFI.endPoint" placeholder="终点">
            <el-option value="汉川电厂" label="汉川电厂"></el-option>
            <el-option value="青山电厂" label="青山电厂"></el-option>
            <el-option value="荆州电厂" label="荆州电厂"></el-option>
            <el-option value="国电九江" label="国电九江"></el-option>
            <el-option value="国华九江" label="国华九江"></el-option>
            <el-option value="丰城电厂" label="丰城电厂"></el-option>
            <el-option value="黄金埠电厂" label="黄金埠电厂"></el-option>
          </el-select>
        </el-form-item> 
        <el-form-item label="运价(元)" prop="money">
          <el-input v-model="inputCBFI.money" type="number"></el-input>
        </el-form-item> 
        <el-form-item label="日期" prop="date">
          <el-date-picker type="date" v-model="inputCBFI.date" value-format="yyyy-MM-dd"></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm('inputCBFI')">添加</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="showInfo">
      <div class="title">运价信息</div>
      <el-form :inline="true" :model="searchInput" style="padding-left:20px;">        
        <el-form-item label="起点">
          <el-select v-model="searchInput.startPoint" placeholder="起点">
            <el-option value="" label="全部"></el-option>
            <el-option value="张家港" label="张家港"></el-option>
            <el-option value="扬子江" label="扬子江"></el-option>
            <el-option value="太仓鑫海" label="太仓鑫海"></el-option>
            <el-option value="太仓华能" label="太仓华能"></el-option>
            <el-option value="江阴中信" label="江阴中信"></el-option>
            <el-option value="南京西坝" label="南京西坝"></el-option>
            <el-option value="扬州海昌" label="扬州海昌"></el-option>
          </el-select>
        </el-form-item>        
        <el-form-item label="终点">
          <el-select v-model="searchInput.endPoint" placeholder="终点">
            <el-option value="" label="全部"></el-option>
            <el-option value="汉川电厂" label="汉川电厂"></el-option>
            <el-option value="青山电厂" label="青山电厂"></el-option>
            <el-option value="荆州电厂" label="荆州电厂"></el-option>
            <el-option value="国电九江" label="国电九江"></el-option>
            <el-option value="国华九江" label="国华九江"></el-option>
            <el-option value="丰城电厂" label="丰城电厂"></el-option>
            <el-option value="黄金埠电厂" label="黄金埠电厂"></el-option>
          </el-select>
        </el-form-item> 
        <el-form-item>
          <el-date-picker type="date" v-model="searchInput.date" placeholder="选择日期" value-format="yyyy-MM-dd"></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="searchCBFIInfo">搜索</el-button>
        </el-form-item>
      </el-form>
      <el-table :data="CBFIDatas" border style="width:98%;max-height:55vh;">
        <el-table-column type="index" label="序号" width="50"></el-table-column>
        <el-table-column prop="transPort" label="起点名称"></el-table-column>
        <el-table-column prop="destiPort" label="终点名称"></el-table-column>
        <el-table-column prop="indicesDate" label="日期">
          <template slot-scope="scope"><span>{{formateDate(scope.row.indicesDate,1)}}</span></template>
        </el-table-column>
        <el-table-column prop="price" label="运费价格(元/吨)"></el-table-column>
        <el-table-column prop="creator" label="创建人"></el-table-column>
        <el-table-column prop="createTime" label="创建时间">
          <template slot-scope="scope"><span>{{formateDate(scope.row.createTime,2)}}</span></template>
        </el-table-column>
        <el-table-column prop="updateTime" label="更新时间">
          <template slot-scope="scope"><span>{{formateDate(scope.row.updateTime,2)}}</span></template>
        </el-table-column>
        <el-table-column label="操作" width="70">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="编辑" placement="right">
              <el-button 
                type="primary" 
                icon="el-icon-edit" 
                size="mini" 
                circle
                plain
                :disabled="!scope.row.status"
                @click="editCBFIInfo(scope.row.id,scope.row.price)"></el-button>
            </el-tooltip>
          </template>        
        </el-table-column>
      </el-table>
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="12"
        :current-page.sync='currPage'
        :total="CBFITotal"
        @current-change="handleCurrPageChange">
      </el-pagination>
    </div>
    <!-- 编辑弹窗 -->
    <el-dialog
      title="编辑"
      :visible.sync="dialogVisible"
      width="15%">
      <el-form> 
        <el-form-item label="运价：">
          <el-input v-model="editPrice" type="number" placeholder="请输入运价（元）"></el-input>
        </el-form-item> 
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleEdit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'CBFI',
  data () {
    return {
      inputCBFI:{startPoint:'', endPoint:'', money:'', date:''},
      searchInput:{startPoint:'', endPoint:'', date:''},
      CBFIDatas:[],
      CBFITotal:0,
      currPage:1,
      dialogVisible:false,
      editID:0,
      editPrice:0,
      rules:{
        startPoint: [
          {required:true, message:'请选择起点', trigger:'change' }
        ],
        endPoint: [
          {required:true, message:'请选择终点', trigger:'change' }
        ],
        money: [
          {required:true, message:'请输入运价', trigger:'blur' }
        ],
        date: [
          {required:true, message:'请选择日期', trigger:'change' }
        ],
      }
    }
  },
  mounted() {
    this.getCBFIList(1,'','','');
  },
  methods: {
    formateDate(timestamp,_type){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? ('0' + minute) : minute;
      if(_type == 1){
        return y + '-' + m + '-' + d;
      }else{
        return y + '-' + m + '-' + d+' '+h+':'+minute;
      }
        
    },
    // 请求运价指数信息
    getCBFIList(_pageNo,_transPort,_destiPort,_indicesDate){
      if(_indicesDate == null){ _indicesDate = ''}
      $.ajax({
        type: "post",
        url: "/indices/page?pageNo="+_pageNo+"&transPort="+_transPort+"&destiPort="+_destiPort+"&indicesDate="+_indicesDate,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.CBFIDatas = respMsg.data.list;
          this.CBFITotal = respMsg.data.totalCount;
        },
        error: (data)=>{console.log(data);}
      });  
    },
    // 输入验证
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.addCBFIInfo();
          this.$refs[formName].resetFields();
        }else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 录入运价指数信息
    addCBFIInfo() {
      $.ajax({
        type: "post",
        url: "/indices/add?transPort="+this.inputCBFI.startPoint+"&destiPort="+this.inputCBFI.endPoint+"&price="+this.inputCBFI.money+"&indicesDate="+this.inputCBFI.date,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.$message({message: '添加成功！', type: 'success'});
          this.currPage = 1;
          this.getCBFIList(this.currPage,'','','');
          this.inputCBFI={startPoint:'', endPoint:'', money:'', date:''};
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    // 搜索
    searchCBFIInfo() {
      this.getCBFIList(1,this.searchInput.startPoint,this.searchInput.endPoint,this.searchInput.date);
    },
    // 编辑
    editCBFIInfo(_id, _price){
      this.editID = _id;
      this.editPrice = _price;
      this.dialogVisible = true;
    },
    handleEdit() {
      $.ajax({
        type: "post",
        url: "/indices/update?id="+this.editID+"&price="+this.editPrice,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.$message({message: '修改成功！',type: 'success'});
          this.dialogVisible = false;
          this.getCBFIList(this.currPage,this.searchInput.startPoint,this.searchInput.endPoint,this.searchInput.date);
        },
        error: (data)=>{console.log(data);}
      });
    },
    handleCurrPageChange(val){
      this.currPage = val;
      this.getCBFIList(val,this.searchInput.startPoint,this.searchInput.endPoint,this.searchInput.date);
    }
  }
}
</script>
<style scoped>
.inputInfo{background:#fff;}
.showInfo{margin-top:15px; background:#fff;}
</style>