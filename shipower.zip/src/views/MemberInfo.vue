<template>
  <div class="memberInfo">
    <div class="title">会员信息</div>
    <div class="searchBox">
      <el-input
        placeholder="请输入会员姓名或电话号"
        prefix-icon="el-icon-search"
        v-model="inputMemberInfo">
      </el-input>
      <el-button type="primary" @click="searchMemberInfo">搜索</el-button>
    </div>
    <el-table :data="memberDatas" border style="width:98%;max-height:69vh;">
      <el-table-column type="index" label="序号" width="50"></el-table-column>
      <el-table-column prop="name" label="会员姓名" width="90"></el-table-column>
      <el-table-column prop="loginName" label="昵称"></el-table-column>
      <el-table-column prop="phone" label="联系电话"></el-table-column>
      <el-table-column prop="type" label="类型">
        <template slot-scope="scope">
          <span v-if="scope.row.type == 1">船东</span>
          <span v-else-if="scope.row.type == -1">安装人员</span>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="状态" width="80">
        <template slot-scope="scope">
          <span v-if="scope.row.status == 0">禁用</span>
          <span v-else-if="scope.row.status == 1">正常</span>
          <span v-else-if="scope.row.status == 2">锁定</span>
        </template>
      </el-table-column>
      <el-table-column prop="vipStatus" label="会员状态" width="80">
        <template slot-scope="scope">
          <span v-if="scope.row.vipStatus == 0">普通用户</span>
          <span v-else-if="scope.row.vipStatus == 1">付费用户</span>
        </template>
      </el-table-column>
      <el-table-column prop="vipDate" label="会员到期时间">
        <template slot-scope="scope">
          <span v-if="scope.row.vipDate != null">{{formateDate(scope.row.vipDate)}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="curProCount" label="当前设备数"></el-table-column>
      <el-table-column prop="createTime" label="创建时间">
        <template slot-scope="scope"><span>{{formateDate(scope.row.createTime)}}</span></template>
      </el-table-column>
      <el-table-column prop="showPhone" label="是否显示通讯录">
        <template slot-scope="scope">
          <span v-if="scope.row.showPhone == 1">是</span>
          <span v-else>否</span>
        </template>
      </el-table-column>
      <el-table-column prop="lastLoginTime" label="最后登录时间">
        <template slot-scope="scope"><span>{{formateDate(scope.row.lastLoginTime)}}</span></template>
      </el-table-column>
      <el-table-column label="操作">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="编辑" placement="right">
              <el-button 
                type="primary" 
                icon="el-icon-edit" 
                size="mini" 
                circle
                plain
                @click="changeMemberInfo(scope.row)"></el-button>
            </el-tooltip>
          </template>        
        </el-table-column>
    </el-table>
    <el-pagination
      background
      layout="prev, pager, next"
      :page-size="12"
      :current-page.sync='currPage'
      :total="membersTotal"
      @current-change="handleCurrPageChange">
    </el-pagination>
    <!-- 编辑会员弹窗 -->
    <el-dialog title="修改会员信息" :visible.sync="dialogMember" width="20%">
      <el-form :model="editMember">        
        <el-form-item label="会员姓名">
          <el-input v-model="editMember.name"></el-input>
        </el-form-item>
        <el-form-item label="昵称">
          <el-input v-model="editMember.loginName"></el-input>
        </el-form-item>
        <el-form-item label="类型">
          <el-select v-model="editMember.type">
            <el-option value="-1" label="安装人员"></el-option>
            <el-option value="1" label="船东"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="editMember.status">
            <el-option value="1" label="正常"></el-option>
            <el-option value="2" label="锁定"></el-option>
            <el-option value="0" label="禁用"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogMember = false">取 消</el-button>
        <el-button type="primary" @click="EditMemberInfo()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'MemberInfo',
  data () {
    return {
      memberDatas: [],
      membersTotal: 0,
      inputMemberInfo: '',
      currPage:1,
      dialogMember: false,
      editMember: {
        mid:'',
        name:'',
        loginName:'',
        type:'',
        status:'',
      },
      MemberType:'',
      MemberStatus: ''
    }
  },
  beforeMount() {
    this.getMemberInfo(1, "");
  },
  methods: {
    formateDate(timestamp){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;  
      m = m < 10 ? ('0' + m) : m;  
      var d = date.getDate();  
      d = d < 10 ? ('0' + d) : d;  
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      minute = minute < 10 ? ('0' + minute) : minute;  
      return y + '-' + m + '-' + d+' '+h+':'+minute;  
    },
    getMemberInfo(_pageNo, _query) {
      $.ajax({
        type: "post",
        url: "/member/page?pageNo="+_pageNo+"&query="+_query,
        dataType: "json",
        success: (data) => {
          if(data.ret !=0){
            console.log(data.msg);
            return;
          }
          this.memberDatas = data.data.list;
          this.membersTotal = data.data.totalCount;
        },
        error: (data) => {console.log(data)}
      });
    },
    searchMemberInfo() {
      this.currPage = 1;
      this.getMemberInfo(this.currPage, this.inputMemberInfo);
    },
    handleCurrPageChange(val) {
      this.currPage = val;
      this.getMemberInfo(val, this.inputMemberInfo);
    },
    changeMemberInfo(row) {
      if(row.type == -1){
        this.editMember.type = '安装人员';
      }else if(row.type == 1){
        this.editMember.type = '船东';
      }
      if(row.status == 1){
        this.editMember.status = '正常';
      }else if(row.status == 2){
        this.editMember.status = '锁定';
      }else{
        this.editMember.status = '禁用';
      }
      this.dialogMember = true;
      this.editMember.mid = row.mid;
      this.editMember.name = row.name;
      this.editMember.loginName = row.loginName;
      this.MemberType = row.type; 
      this.MemberStatus = row.status;
    },
    EditMemberInfo() {
      var a = /[0-9]/; 
      if(!a.test(this.editMember.type)){
        this.editMember.type = this.MemberType;
      }
      if(!a.test(this.editMember.status)){
        this.editMember.status = this.MemberStatus;
      }
      $.ajax({
        type: "post",
        url: "/member/update?mid="+this.editMember.mid+"&name="+this.editMember.name+"&loginName="+this.editMember.loginName+"&type="+this.editMember.type+"&status="+this.editMember.status,
        dataType: "json",
        success: (data) => {
          if(data.ret !=0){
            console.log(data.msg);
            return;
          }
          this.dialogMember = false;
          this.$message({message:'修改成功', type:'success' });
          this.getMemberInfo(this.currPage, this.inputMemberInfo);
        },
        error: (data) => {console.log(data)}
      });
    }
  }
}
</script>
<style scoped>
.memberInfo{height: 100%; background: #fff;}
</style>