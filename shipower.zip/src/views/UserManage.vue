<template>
  <div class="userManage">
    <div class="inputInfo">
      <div class="title">新增用户</div>
      <el-form :inline="true" :model="inputUser" ref="inputUser" style="padding-left:20px;">
        <div>
          <el-form-item label="用户名" prop="loginName" :rules="[{required:true, message:'请输入用户名'}]">
            <el-input v-model="inputUser.loginName" maxlength="16" show-word-limit placeholder="请输入用户名"></el-input>
          </el-form-item>
          <el-form-item label="真实姓名" prop="realName" :rules="[{required:true, message:'请输入真实姓名'}]">
            <el-input v-model="inputUser.realName" maxlength="16" show-word-limit placeholder="请输入真实姓名"></el-input>
          </el-form-item>
          <el-form-item label="联系电话" prop="phone" :rules="[{required:true, message:'请输入联系电话'}]">
            <el-input v-model="inputUser.phone" type="number" placeholder="请输入电话"></el-input>
          </el-form-item>
          <el-form-item label="所属部门">
            <el-select v-model="inputUser.departId" placeholder="请选择所属部门">
              <el-option value="-1" label="安装部">安装部</el-option>
              <el-option value="1" label="技术部">技术部</el-option>
              <el-option value="2" label="运营部">运营部</el-option>
              <el-option value="3" label="其他">其他</el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('inputUser')">添加</el-button>
          </el-form-item>
        </div>
      </el-form>
    </div>
    <div class="showInfo">
      <div class="title">用户信息</div>
      <el-table :data="userDatas" border style="width:98%;max-height:59vh;">
        <el-table-column type="index" label="序号" width="50"></el-table-column>
        <el-table-column prop="loginName" label="用户名"></el-table-column>
        <el-table-column prop="realName" label="真实姓名"></el-table-column>
        <el-table-column prop="phone" label="联系方式"></el-table-column>
        <el-table-column prop="departId" label="部门">
         <template slot-scope="scope">
            <span v-if="scope.row.departId == -1">安装部</span>
            <span v-else-if="scope.row.departId == 1">技术部</span>
            <span v-else-if="scope.row.departId == 2">运营部</span>
            <span v-else>其他</span>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间">
          <template slot-scope="scope"><span>{{formateDate(scope.row.createTime)}}</span></template>
        </el-table-column>
        
        <el-table-column prop="loginTime" label="登录时间">
          <template slot-scope="scope"><span v-if="scope.row.loginTime != null">{{formateDate(scope.row.loginTime)}}</span></template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="编辑" placement="right">
              <el-button 
                type="primary" 
                icon="el-icon-edit" 
                size="mini" 
                circle
                plain
                @click="changeUserInfo(scope.row)"></el-button>
            </el-tooltip>
          </template>        
        </el-table-column>
      </el-table>
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="12"
        :current-page.sync='currPage'
        :total="userTotal"
        @current-change="handleCurrPageChange">
      </el-pagination>
    </div>
    <!-- 编辑用户弹窗 -->
    <el-dialog title="修改用户信息" :visible.sync="dialogUser" width="30%">
      <el-form :model="editUser" style="padding-left:20px;">        
        <el-form-item label="用户名">
          <el-input v-model="editUser.loginName" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="真实姓名">
          <el-input v-model="editUser.realName" maxlength="16" show-word-limit></el-input>
        </el-form-item>
        <el-form-item label="联系电话">
          <el-input v-model="editUser.phone" type="number"></el-input>
        </el-form-item>
        <el-form-item label="所属部门">
          <el-select v-model="editUser.departId" placeholder="流程节点">
            <el-option value="-1" label="安装部">安装部</el-option>
            <el-option value="1" label="技术部">技术部</el-option>
            <el-option value="2" label="运营部">运营部</el-option>
            <el-option value="3" label="其他">其他</el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="editUser.status"></el-switch>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogUser = false">取 消</el-button>
        <el-button type="primary" @click="EditUserInfo()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'UserManage',
  data () {
    return {
      inputUser:{
        loginName:'', //登录名
        realName:'', //真实姓名
        departId:'', //部门id（-1：安装部，1：技术部，2：运营部，3：其他）
        phone:'' //电话
      },
      userDatas:[],
      userTotal:0,
      currPage:1,
      dialogUser: false,
      editUser:{
        id:'',
        loginName:'', //登录名
        realName:'', //真实姓名
        departId:'', //部门id（-1：安装部，1：技术部，2：运营部，3：其他）
        phone:'', //电话
        status:false,
        departName:''
      },
      status:1
    }
  },
  mounted() {
    this.getUserDatas(1);
  },
  methods: {
    formateDate(timestamp){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      var second = date.getSeconds();
      minute = minute < 10 ? ('0' + minute) : minute;
      second = second < 10 ? ('0' + second) : second;
      return y + '-' + m + '-' + d+' '+h+':'+minute+':'+second;  
    },
    // 输入验证
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.addUser();
          this.$refs[formName].resetFields();
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 添加新用户
    addUser(){
      $.ajax({
        type: "post",
        url: "/user/save?loginName="+this.inputUser.loginName+"&realName="+this.inputUser.realName+"&departId="+this.inputUser.departId+"&phone="+this.inputUser.phone,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.inputUser.loginName = '';
          this.inputUser.realName = '';
          this.inputUser.phone = '';
          this.inputUser.departId = '';
          this.$message({message: '添加成功！', type: 'success' });
          this.currPage = 1;
          this.getUserDatas(1);
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    // 请求所有的用户信息
    getUserDatas(_pageNo) {
      $.ajax({
        type: "post",
        url: "/user/page?pageNo="+_pageNo,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.userDatas = respMsg.data.list;
          this.userTotal = respMsg.data.totalCount;
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    changeUserInfo(row){
      var _status = 1;
      if(row.status){
        this.editUser.status = true;
      }else{
        this.editUser.status = false;
      }
      if(row.departId == -1){
        this.editUser.departId = '安装部';
      }else if(row.departId == 1){
        this.editUser.departId = '技术部';
      }else if(row.departId == 2){
        this.editUser.departId = '运营部';
      }else{
        this.editUser.departId = '其他';
      }
      this.editUser.id = row.id;
      this.editUser.loginName = row.loginName; //登录名
      this.editUser.realName = row.realName; //真实姓名
      this.departName = row.departId; //部门id（-1：安装部，1：技术部，2：运营部，3：其他）
      this.editUser.phone = row.phone; //电话
      this.dialogUser = true;
    },
    EditUserInfo(_id) {
      if(this.editUser.status){
        this.status = 1;
      }else{
        this.status = 0;
      }
      var a = /[0-9]/; 
      if(!a.test(this.editUser.departId)){
        this.editUser.departId = this.departName;
      }
      $.ajax({
        type: "post",
        url: "/user/update?id="+this.editUser.id+"&loginName="+this.editUser.loginName+"&realName="+this.editUser.realName+"&departId="+this.editUser.departId+"&phone="+this.editUser.phone+"&status="+this.status,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.dialogUser = false;
          this.getUserDatas(this.currPage);
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    handleCurrPageChange(val){
      this.currPage = val;
      this.getUserDatas(val);
    }
  }
}
</script>
<style scoped>
.userManage{height: 100%;}
.inputInfo{background: #fff;}
.showInfo{background:#fff; margin-top:15px; height:82%;}
</style>