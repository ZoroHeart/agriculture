<template>
  <div class="dataMaintain">
    <div class="inputInfo">
      <div class="title">录入数据</div>
      <el-form :inline="true" :model="inputCarrier" ref="inputCarrier" style="padding-left:20px;">
        <el-form-item label="航运公司名称" prop="carrierName" :rules="[{required:true, message:'航运公司不能为空'}]">
          <el-input type="carrierName" v-model="inputCarrier.carrierName" maxlength="16" show-word-limit autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="联系电话" prop="carrierPhone"
          :rules="[
            { required: true, message: '联系电话不能为空'},
            { type: 'number', message: '联系电话必须为数字值'}
          ]">
          <el-input type="carrierPhone" v-model.number="inputCarrier.carrierPhone"></el-input>
        </el-form-item> 
        <el-form-item>
          <el-button type="primary" @click="submitForm('inputCarrier')">添加</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="showInfo">
      <div class="title">数据信息</div>
      <el-table :data="carrierDatas" border style="width:98%;max-height:59vh;">
        <el-table-column type="index" label="序号" width="50"></el-table-column>
        <el-table-column prop="comp" label="航运公司名称"></el-table-column>
        <el-table-column prop="carrierPhone" label="联系电话"></el-table-column>
        <el-table-column prop="createTime" label="提交时间">
          <template slot-scope="scope"><span>{{formateDate(scope.row.createTime)}}</span></template>
        </el-table-column>
        <el-table-column prop="updateTime" label="更新时间">
          <template slot-scope="scope"><span>{{formateDate(scope.row.updateTime)}}</span></template>
        </el-table-column>
        <el-table-column prop="creator" label="创建人"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-tooltip class="item" effect="dark" content="删除" placement="right">
              <el-button 
                type="danger" 
                icon="el-icon-delete" 
                size="mini" 
                circle
                :disabled="!scope.row.status"
                @click="DeleteCarrierInfo(scope.row.id)"></el-button>
            </el-tooltip>
          </template>        
        </el-table-column>
      </el-table>
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="12"
        :current-page.sync='currPageNum'
        :total="carrierTotal"
        @current-change="handleCurrPageChange">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: 'DataMaintain',
  data () {
    return {
      inputCarrier:{
        carrierName:'',
        carrierPhone:''
      },
      carrierDatas:[],
      carrierTotal:0,
      currPageNum:1 
    }
  },
  mounted() {
    this.getCarrierList(1);
  },
  methods: {
    formateDate(timestamp){
      var date = new Date(timestamp);
      var y = date.getFullYear();
      var m = date.getMonth() + 1;  
      m = m < 10 ? ('0' + m) : m;  
      var d = date.getDate();  
      d = d < 10 ? ('0' + d) : d;  
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      var second = date.getSeconds();
      minute = minute < 10 ? ('0' + minute) : minute;  
      second = second < 10 ? ('0' + second) : second; 
      return y + '-' + m + '-' + d+' '+h+':'+minute+':'+second;  
    },
    getCarrierList(_pageNo){
      $.ajax({
        type: "get",
        url: "/carrier/page?pageNo="+_pageNo,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.carrierDatas = respMsg.data.list;
          this.carrierTotal = respMsg.data.totalCount;
        },
        error: (data)=>{console.log(data);}
      });  
    },
    // 输入验证
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.addCarrierInfo();
          this.$refs[formName].resetFields();
        }else {
          return false;
        }
      });
    },
    // 录入航运公司信息
    addCarrierInfo() {
      $.ajax({
        type: "post",
        url: "/carrier/add?comp="+this.inputCarrier.carrierName+"&carrierPhone="+this.inputCarrier.carrierPhone,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.$message({message: '添加成功！',type: 'success'});
          this.currPageNum = 1;
          this.getCarrierList(this.currPageNum);
          this.inputCarrier.carrierName = '';
          this.inputCarrier.carrierPhone = '';
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    DeleteCarrierInfo(_id) {
      $.ajax({
        type: "post",
        url: "/carrier/del?id="+_id,
        dataType: "json",
        success: (respMsg) => {
          if(respMsg.ret != 0){
            this.$message.error(respMsg.msg);
            return;
          }
          this.$message({type: 'info',message: `删除成功！`});
          this.getCarrierList(this.currPageNum);
        },
        error: (data)=>{console.log(data);}
      }); 
    },
    handleCurrPageChange(val){
      this.currPageNum = val;
      this.getCarrierList(val);
    }
  }
}
</script>
<style scoped>
.inputInfo{background:#fff;}
.showInfo{margin-top:15px; background:#fff;}
</style>