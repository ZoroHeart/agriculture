import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/views/Login'
import Home from '@/views/Home'

Vue.use(Router)

export default new Router({
  // mode: 'history',  //去掉url中的#
  linkActiveClass: 'active',
  routes: [
    {
      path: '/',
      name: '/',
      redirect: '/login' //会把url重新指向/login ；
    },
    {
      path: '/login',
      name: 'Login',
      component: Login,
    },
    {
      path:'/home',
      name:'home',
      component:Home,
      children: [
        {
          path: '/home/sourceInfo',
          name: 'sourceInfo',
          component: resolve => require(['../views/SourceInfo.vue'], resolve)
        }, {
          path: '/home/shipInfo',
          name: 'shipInfo',
          component: resolve => require(['../views/ShipInfo.vue'],resolve)
        }, {
          path: '/home/airshipInfo',
          name: 'airshipInfo',
          component: resolve => require(['../views/AirshipInfo.vue'], resolve)
        }, {
          path: '/home/memberInfo',
          name: 'memberInfo',
          component: resolve => require(['../views/MemberInfo.vue'], resolve)
        }, {
          path: '/home/deviceManage',
          name: 'deviceManage',
          component: resolve => require(['../views/DeviceManage.vue'], resolve)
        }, {
          path: '/home/userManage',
          name: 'userManage',
          component: resolve => require(['../views/UserManage.vue'], resolve)
        }, {
          path: '/home/dataMaintain',
          name: 'dataMaintain',
          component: resolve => require(['../views/DataMaintain.vue'], resolve)
        }, {
          path: '/home/CBFI',
          name: 'CBFI',
          component: resolve => require(['../views/CBFI.vue'], resolve)
        }
      ]
    }
  ]
})
