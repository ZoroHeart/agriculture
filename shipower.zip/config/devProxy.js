let proxy = {};
proxy = {
    '/admin/': { target: 'http://106.52.225.36:9091', changeOrigin: true },
    '/dologin': { target: 'http://106.52.225.36:9091', changeOrigin: true },
    '/carrier/': { target: 'http://106.52.225.36:9091', changeOrigin: true }
}

module.exports = proxy;